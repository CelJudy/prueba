/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package asesoria;

/**
 *
 * @author celju2
 */
public class Asesoria {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
    public void imprimir(){
        System.out.println("Hola mundo");
    }
    
    public String concatenar(){
        return "Hola mundo";
    }
    
    public int sumar(int numero1){
        return numero1++;
    }
    public int restar(int numero1){
        return numero1--;
    }
    
}
